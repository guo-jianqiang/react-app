import React, { Component } from 'react'
import cs from 'classnames'
import './style.scss'

class Cascader extends Component {
  static defaultProps = {
    tree: []
  }

  constructor (props, context) {
    super(props, context)
    this.state = {
      parentCurrentId: undefined,
      childrenCurrentId: undefined
    }
  }

  componentDidUpdate (prevProps, prevState, snapshot) {
    if (prevProps.tree !== this.props.tree) {
      this.setState({parentCurrentId: this.props.tree[0].id, childrenCurrentId: undefined})
    }
  }

  handleClickLeft = item => {
    this.setState({parentCurrentId: item.id, childrenCurrentId: undefined})
    typeof this.props.handleClickLeft === 'function' && this.props.handleClickLeft(item)
  }

  handleClickRight = item => {
    this.setState({childrenCurrentId: item.id})
    typeof this.props.handleClickRight === 'function' && this.props.handleClickRight(item)
  }

  render () {
    const {tree} = this.props
    const childrenIndex = tree.findIndex(item => item.id === this.state.parentCurrentId)
    return (
      <div className='cascader'>
        <div className='cascader-list'>
          {
            tree.map(item => (
              <div
                key={item.id}
                className={cs('cascader-list-item', {
                  'cascader-list-active': item.id === this.state.parentCurrentId
                })}
                onClick={() => {
                  this.handleClickLeft(item)
                }}
              >{item.text}</div>
            ))
          }
        </div>
        <div className='cascader-list'>
          {
            tree.length && tree[childrenIndex]?.children ? tree[childrenIndex]?.children.map(item => (
              <div
                key={item.id}
                className={cs('cascader-list-item', {
                  'cascader-list-active': item.id === this.state.childrenCurrentId
                })}
                onClick={() => {
                  this.handleClickRight(item)
                }}
              >
                {item.text}
              </div>
            )) : null
          }
        </div>
      </div>
    )
  }
}

export default Cascader